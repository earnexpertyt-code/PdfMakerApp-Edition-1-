# PDF Maker — Android

A real Android app project for an offline-first Image → PDF workflow.

## What is implemented

- Multi-image import from Android's Storage Access Framework (gallery/files)
- Camera capture through the system camera app
- Page organizer: reorder (drag gesture + up/down fallback), delete, duplicate, rotate
- Per-page image processing: brightness, contrast, saturation, grayscale, black & white, crop, rotate
- Non-destructive editing: source image URIs are never overwritten
- PDF export with A4/A5/Letter/Legal/Square/custom dimensions, portrait/landscape, margins and Fit/Fill/Center placement
- Quality and compression presets
- Page numbers and diagonal watermark
- PDF title/author/subject/keywords metadata when supplied (PDFBox post-processing)
- Local PDF history: open, share, rename, delete, search
- Native Android sharing and external PDF viewer integration
- Progress + cancellation handling
- First-run onboarding
- Dark-mode setting
- Low-RAM minded image decoding: bounds probing + sampling; one processed page at a time
- Clear privacy messaging and app-private PDF storage

## Architecture

`MainActivity` hosts Compose navigation state and delegates work to focused classes:

- `Models.kt` — immutable page/settings/history models
- `ImageProcessor.kt` — sampled bitmap decoding, crop/rotation/color processing
- `PdfGenerator.kt` — native `android.graphics.pdf.PdfDocument` export + optional PDFBox metadata pass
- `DocumentStore.kt` — lightweight local history persistence using SharedPreferences/JSON

The core workflow is offline-first. No server or upload endpoint exists in the project.

## Build

1. Open this folder in Android Studio (Quail 4 or newer is appropriate for the current Android toolchain).
2. Let Gradle sync.
3. Build the `app` module and run on an Android 7.1+ device/emulator.
4. Grant camera permission only when using camera capture.

Current toolchain choices follow current Android guidance: AGP 9.4.0, Kotlin 2.3.21, Compose BOM 2026.08.00, Activity 1.13.0 and Core 1.19.0.

## Important practical limitations

The project deliberately does **not** advertise unsupported features as working:

- Automatic document-edge detection / four-corner perspective correction is not bundled in the core build. Camera capture + manual crop is implemented.
- OCR/searchable PDF text-layer generation is not included in this compact offline build. Adding bundled ML Kit OCR is feasible, but it increases APK size; true searchable PDFs also need a text-layer PDF pipeline.
- PDF-to-PDF merge/split/extract is not exposed in the UI. PDFBox is included for metadata support and can be used in a future document-operations module.
- Android's native PDF generator has limited low-level PDF features compared with a full PDF authoring engine.

## Testing checklist

- 1 / 5 / 20+ images
- Mixed portrait/landscape inputs
- Large images and low-storage conditions
- A4 portrait/landscape and custom page sizes
- Crop, rotate and image adjustments
- Quality/compression combinations
- Cancelled export
- Missing/unsupported images
- Permission denial
- History open/share/rename/delete/search
- App restart after PDF creation

## Privacy

The main workflow uses local device processing and app-private storage. The app does not upload imported images or PDFs to a backend.
