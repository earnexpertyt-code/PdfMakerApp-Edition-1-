# Toolchain note

This project targets Android API 37 and uses AGP 9.4.0. AGP 9.4 requires Gradle 9.6.0 and JDK 17+, and supports API 37. Android Studio Quail 4 is the matching stable IDE line.

The Compose setup follows the current Compose BOM 2026.08.00 guidance.
