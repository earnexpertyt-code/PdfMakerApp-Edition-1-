# PdfMakerApp: native Android APIs only; keep this file for future rules.
