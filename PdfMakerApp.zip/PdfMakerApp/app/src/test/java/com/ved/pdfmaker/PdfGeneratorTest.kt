package com.ved.pdfmaker

import org.junit.Assert.assertEquals
import org.junit.Test

class PdfGeneratorTest {
    @Test fun sampleSizeStaysPowerOfTwo() {
        assertEquals(4, ImageProcessor.calculateInSampleSize(4000, 3000, 1000))
        assertEquals(1, ImageProcessor.calculateInSampleSize(900, 700, 1000))
    }

    @Test fun defaultPageSettingsAreA4Portrait() {
        val settings = PdfSettings()
        assertEquals(PageSize.A4, settings.pageSize)
        assertEquals(Orientation.PORTRAIT, settings.orientation)
    }
}
