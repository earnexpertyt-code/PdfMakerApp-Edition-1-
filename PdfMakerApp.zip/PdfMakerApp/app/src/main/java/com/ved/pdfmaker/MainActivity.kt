package com.ved.pdfmaker

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.launch
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {
    private val executor = Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PdfMakerApp() }
    }

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }

    private fun openUri(context: Context, uri: Uri, type: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, type)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "No app found to open this file.", Toast.LENGTH_LONG).show()
        }
    }

    @Composable
    private fun PdfMakerApp() {
        var screen by remember { mutableStateOf(Screen.HOME) }
        var pages by remember { mutableStateOf(listOf<PageItem>()) }
        var selectedIndex by remember { mutableStateOf(0) }
        var settings by remember { mutableStateOf(PdfSettings()) }
        var processing by remember { mutableStateOf(false) }
        var progress by remember { mutableStateOf(0 to 0) }
        var error by remember { mutableStateOf<String?>(null) }
        var showOnboarding by remember { mutableStateOf(!getPreferences(0).getBoolean("onboarding", false)) }
        val context = LocalContext.current
        val store = remember { DocumentStore(context) }
        var records by remember { mutableStateOf(store.list()) }
        var darkMode by remember { mutableStateOf(getPreferences(0).getBoolean("dark_mode", false)) }

        val galleryLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            val imported = uris.mapIndexed { i, uri -> PageItem(System.nanoTime() + i, uri) }
            if (imported.isNotEmpty()) { pages = pages + imported; screen = Screen.ORGANIZE }
        }
        val cameraFile = remember { File(context.cacheDir, "camera_${System.currentTimeMillis()}.jpg") }
        val cameraUri = remember(cameraFile) { FileProvider.getUriForFile(context, "com.ved.pdfmaker.fileprovider", cameraFile) }
        var pendingCamera by remember { mutableStateOf(false) }
        val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
            pendingCamera = false
            if (ok && cameraFile.exists()) {
                pages = pages + PageItem(System.nanoTime(), cameraUri)
                screen = Screen.EDIT
                selectedIndex = pages.lastIndex
            }
        }
        val cameraPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) cameraLauncher.launch(cameraUri) else error = "Camera permission was denied. You can enable it in Settings."
        }

        fun takePhoto() {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) cameraLauncher.launch(cameraUri)
            else cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }

        MaterialTheme(colorScheme = if (darkMode) darkColorScheme(primary = Color(0xFFD0BCFF)) else lightColorScheme(primary = Color(0xFF6C4AB6))) {
            Scaffold(
                bottomBar = { BottomNav(screen) { screen = it } }
            ) { inner ->
                Surface(Modifier.fillMaxSize().padding(inner)) {
                    when (screen) {
                        Screen.HOME -> HomeScreen(
                            recent = records.take(3),
                            onCreate = { galleryLauncher.launch(arrayOf("image/*")) },
                            onCamera = { takePhoto() },
                            onPdfs = { screen = Screen.PDFS },
                            onOpen = { rec -> openUri(context, FileProvider.getUriForFile(context, "com.ved.pdfmaker.fileprovider", File(rec.path)), "application/pdf") }
                        )
                        Screen.CREATE -> CreateScreen(
                            onGallery = { galleryLauncher.launch(arrayOf("image/*")) },
                            onCamera = { takePhoto() },
                            count = pages.size,
                            onContinue = { if (pages.isNotEmpty()) screen = Screen.ORGANIZE else error = "Select at least one image." }
                        )
                        Screen.ORGANIZE -> OrganizerScreen(
                            pages = pages,
                            onBack = { screen = Screen.CREATE },
                            onAdd = { galleryLauncher.launch(arrayOf("image/*")) },
                            onDelete = { idx -> pages = pages.filterIndexed { i, _ -> i != idx }; selectedIndex = (selectedIndex.coerceAtMost(maxOf(0, pages.lastIndex))) },
                            onDuplicate = { idx -> pages = pages.toMutableList().apply { add(idx + 1, get(idx).copy(id = System.nanoTime())) } },
                            onRotate = { idx -> pages = pages.mapIndexed { i, p -> if (i == idx) p.copy(rotation = (p.rotation + 90) % 360) else p } },
                            onMove = { from, to -> pages = pages.toMutableList().apply { val item = removeAt(from); add(to.coerceIn(0, size), item) } },
                            onEdit = { idx -> selectedIndex = idx; screen = Screen.EDIT },
                            onExport = { screen = Screen.EXPORT }
                        )
                        Screen.EDIT -> EditScreen(
                            page = pages.getOrNull(selectedIndex),
                            onBack = { screen = Screen.ORGANIZE },
                            onUpdate = { updated -> if (updated != null) pages = pages.mapIndexed { i, p -> if (i == selectedIndex) updated else p } },
                            onNext = { if (selectedIndex < pages.lastIndex) selectedIndex++ else screen = Screen.EXPORT },
                            canNext = selectedIndex < pages.lastIndex,
                            index = selectedIndex,
                            total = pages.size
                        )
                        Screen.EXPORT -> ExportScreen(
                            pages = pages,
                            settings = settings,
                            onSettings = { settings = it },
                            processing = processing,
                            progress = progress,
                            onCancel = { processing = false },
                            onBack = { screen = Screen.ORGANIZE },
                            onExport = {
                                if (processing) return@ExportScreen
                                processing = true; error = null
                                executor.execute {
                                    try {
                                        val result = PdfGenerator.generate(context, pages, settings, File(context.filesDir, "pdfs"), { done, total -> runOnUiThread { progress = done to total } }, { !processing })
                                        val rec = PdfRecord(result.file.hashCode().toLong(), result.file.nameWithoutExtension, result.file.absolutePath, System.currentTimeMillis(), result.file.length(), result.pages)
                                        store.add(rec)
                                        runOnUiThread { processing = false; records = store.list(); screen = Screen.PDFS; Toast.makeText(context, "PDF created successfully.", Toast.LENGTH_SHORT).show() }
                                    } catch (e: PdfGenerator.CancellationException) {
                                        runOnUiThread { processing = false }
                                    } catch (e: Exception) {
                                        runOnUiThread { processing = false; error = e.message ?: "PDF generation failed." }
                                    }
                                }
                            },
                            error = error,
                            clearError = { error = null }
                        )
                        Screen.PDFS -> PdfHistoryScreen(
                            records = records,
                            onOpen = { rec -> openUri(context, FileProvider.getUriForFile(context, "com.ved.pdfmaker.fileprovider", File(rec.path)), "application/pdf") },
                            onShare = { rec -> shareFile(context, File(rec.path)) },
                            onDelete = { rec -> File(rec.path).delete(); store.remove(rec.id); records = store.list() },
                            onRename = { rec, name -> store.rename(rec.id, name); records = store.list() }
                        )
                        Screen.SETTINGS -> SettingsScreen(darkMode) { darkMode = it; getPreferences(0).edit().putBoolean("dark_mode", it).apply() }
                        Screen.ABOUT -> AboutScreen()
                    }
                }
            }
        }

        if (showOnboarding) OnboardingDialog { getPreferences(0).edit().putBoolean("onboarding", true).apply(); showOnboarding = false }
    }

    private fun shareFile(context: Context, file: File) {
        val uri = FileProvider.getUriForFile(context, "com.ved.pdfmaker.fileprovider", file)
        context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "application/pdf"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }, "Share PDF"))
    }

    @Composable private fun BottomNav(screen: Screen, onSelect: (Screen) -> Unit) {
        NavigationBar {
            NavigationBarItem(screen == Screen.HOME, { onSelect(Screen.HOME) }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Home") })
            NavigationBarItem(screen == Screen.CREATE || screen == Screen.ORGANIZE || screen == Screen.EDIT || screen == Screen.EXPORT, { onSelect(Screen.CREATE) }, icon = { Icon(Icons.Default.Add, null) }, label = { Text("Create") })
            NavigationBarItem(screen == Screen.PDFS, { onSelect(Screen.PDFS) }, icon = { Icon(Icons.Default.PictureAsPdf, null) }, label = { Text("My PDFs") })
            NavigationBarItem(screen == Screen.SETTINGS, { onSelect(Screen.SETTINGS) }, icon = { Icon(Icons.Default.Settings, null) }, label = { Text("Settings") })
        }
    }
}

@Composable private fun HomeScreen(recent: List<PdfRecord>, onCreate: () -> Unit, onCamera: () -> Unit, onPdfs: () -> Unit, onOpen: (PdfRecord) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item { Text("PDF Maker", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold) }
        item { Text("Images → arrange → edit → professional PDF", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ActionCard("Create PDF", "Import images", Icons.Default.Collections, onCreate, Modifier.weight(1f))
                ActionCard("Scan", "Use camera", Icons.Default.DocumentScanner, onCamera, Modifier.weight(1f))
            }
        }
        item { OutlinedButton(onClick = onPdfs, Modifier.fillMaxWidth()) { Icon(Icons.Default.Folder, null); Spacer(Modifier.width(8.dp)); Text("My PDFs") } }
        item { Text("Recent", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold) }
        if (recent.isEmpty()) item { EmptyState("No PDFs yet", "Create your first PDF from images.") }
        items(recent) { rec -> PdfRow(rec, onOpen) }
    }
}

@Composable private fun CreateScreen(onGallery: () -> Unit, onCamera: () -> Unit, count: Int, onContinue: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Create PDF", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Select images from your phone or capture pages with the camera.")
        Button(onClick = onGallery, Modifier.fillMaxWidth().height(54.dp)) { Icon(Icons.Default.Collections, null); Spacer(Modifier.width(8.dp)); Text("Import Images") }
        OutlinedButton(onClick = onCamera, Modifier.fillMaxWidth().height(54.dp)) { Icon(Icons.Default.PhotoCamera, null); Spacer(Modifier.width(8.dp)); Text("Capture with Camera") }
        Spacer(Modifier.weight(1f))
        Text("${count} image${if (count == 1) "" else "s"} selected", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Button(onClick = onContinue, enabled = count > 0, Modifier.fillMaxWidth().height(52.dp)) { Text("Continue to Arrange") }
    }
}

@Composable private fun OrganizerScreen(pages: List<PageItem>, onBack: () -> Unit, onAdd: () -> Unit, onDelete: (Int) -> Unit, onDuplicate: (Int) -> Unit, onRotate: (Int) -> Unit, onMove: (Int, Int) -> Unit, onEdit: (Int) -> Unit, onExport: () -> Unit) {
    var dragging by remember { mutableStateOf<Int?>(null) }
    Column(Modifier.fillMaxSize()) {
        TopBar("Arrange pages", onBack)
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("${pages.size} pages", fontWeight = FontWeight.SemiBold)
            OutlinedButton(onClick = onAdd) { Icon(Icons.Default.Add, null); Text("Add") }
        }
        LazyColumn(Modifier.weight(1f).padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            itemsIndexed(pages, key = { _, p -> p.id }) { index, item ->
                var dragDistance by remember { mutableFloatStateOf(0f) }
                Card(Modifier.fillMaxWidth().pointerInput(pages, index) {
                    detectDragGesturesAfterLongPress(
                        onDragStart = { dragging = index; dragDistance = 0f },
                        onDrag = { change, amount -> change.consume(); dragDistance += amount.y },
                        onDragEnd = {
                            val from = dragging
                            if (from != null) {
                                val delta = (dragDistance / 92f).toInt()
                                if (delta != 0) onMove(from, (from + delta).coerceIn(0, pages.lastIndex))
                            }
                            dragging = null; dragDistance = 0f
                        },
                        onDragCancel = { dragging = null; dragDistance = 0f }
                    )
                }) {
                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("${index + 1}", Modifier.width(28.dp), fontWeight = FontWeight.Bold)
                        Thumbnail(item.uri, Modifier.size(72.dp).clip(MaterialTheme.shapes.small))
                        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) { Text("Page ${index + 1}", fontWeight = FontWeight.SemiBold); Text("Long press to pick up", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                        IconButton(onClick = { if (index > 0) onMove(index, index - 1) }, enabled = index > 0) { Icon(Icons.Default.KeyboardArrowUp, "Move up") }
                        IconButton(onClick = { if (index < pages.lastIndex) onMove(index, index + 1) }, enabled = index < pages.lastIndex) { Icon(Icons.Default.KeyboardArrowDown, "Move down") }
                        IconButton(onClick = { onRotate(index) }) { Icon(Icons.Default.Rotate90DegreesCw, "Rotate") }
                        IconButton(onClick = { onDuplicate(index) }) { Icon(Icons.Default.ContentCopy, "Duplicate") }
                        IconButton(onClick = { onDelete(index) }) { Icon(Icons.Default.Delete, "Delete") }
                        IconButton(onClick = { onEdit(index) }) { Icon(Icons.Default.Edit, "Edit") }
                    }
                }
            }
        }
        Button(onClick = onExport, enabled = pages.isNotEmpty(), Modifier.fillMaxWidth().padding(16.dp).height(52.dp)) { Icon(Icons.Default.PictureAsPdf, null); Spacer(Modifier.width(8.dp)); Text("Preview & Export") }
    }
}

@Composable private fun EditScreen(page: PageItem?, onBack: () -> Unit, onUpdate: (PageItem?) -> Unit, onNext: () -> Unit, canNext: Boolean, index: Int, total: Int) {
    if (page == null) return
    var brightness by remember(page.id) { mutableFloatStateOf(page.brightness) }
    var contrast by remember(page.id) { mutableFloatStateOf(page.contrast) }
    var saturation by remember(page.id) { mutableFloatStateOf(page.saturation) }
    var grayscale by remember(page.id) { mutableStateOf(page.grayscale) }
    var bw by remember(page.id) { mutableStateOf(page.blackAndWhite) }
    var showCrop by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        TopBar("Edit page ${index + 1} / $total", onBack)
        Column(Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Thumbnail(page.uri, Modifier.fillMaxWidth().height(300.dp).clip(MaterialTheme.shapes.medium), maxSide = 1000)
            Spacer(Modifier.height(12.dp))
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item { SliderRow("Brightness", brightness, -1f..1f) { brightness = it } }
                item { SliderRow("Contrast", contrast, 0.5f..2f) { contrast = it } }
                item { SliderRow("Saturation", saturation, 0f..2f) { saturation = it } }
                item { Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(grayscale, { grayscale = it }); Text("Grayscale") } }
                item { Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(bw, { bw = it }); Text("Black & white") } }
                item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { onUpdate(page.copy(rotation = (page.rotation + 90) % 360)) }) { Icon(Icons.Default.Rotate90DegreesCw, null); Text("Rotate") }
                    OutlinedButton(onClick = { showCrop = true }) { Icon(Icons.Default.Crop, null); Text("Crop") }
                } }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = { onUpdate(page.copy(brightness = 0f, contrast = 1f, saturation = 1f, grayscale = false, blackAndWhite = false)) }, Modifier.weight(1f)) { Text("Reset") }
                Button(onClick = { onUpdate(page.copy(brightness = brightness, contrast = contrast, saturation = saturation, grayscale = grayscale, blackAndWhite = bw)); onNext() }, Modifier.weight(1f)) { Text(if (canNext) "Next page" else "Export") }
            }
        }
    }
    if (showCrop) CropDialog(page) { cropped -> showCrop = false; if (cropped != null) onUpdate(cropped) }
}

@Composable private fun CropDialog(page: PageItem, onResult: (PageItem?) -> Unit) {
    var left by remember { mutableFloatStateOf(page.crop?.left ?: 0f) }
    var top by remember { mutableFloatStateOf(page.crop?.top ?: 0f) }
    var right by remember { mutableFloatStateOf(page.crop?.right ?: 1f) }
    var bottom by remember { mutableFloatStateOf(page.crop?.bottom ?: 1f) }
    AlertDialog(onDismissRequest = { onResult(null) }, title = { Text("Crop") }, text = {
        Column { Text("Adjust crop bounds. Values are percentages of the original image.", fontSize = 13.sp); Slider(value = left, onValueChange = { left = it.coerceAtMost(right - 0.05f) }, valueRange = 0f..0.9f); Slider(value = top, onValueChange = { top = it.coerceAtMost(bottom - 0.05f) }, valueRange = 0f..0.9f); Slider(value = right, onValueChange = { right = it.coerceAtLeast(left + 0.05f) }, valueRange = 0.1f..1f); Slider(value = bottom, onValueChange = { bottom = it.coerceAtLeast(top + 0.05f) }, valueRange = 0.1f..1f) }
    }, confirmButton = { TextButton(onClick = { onResult(page.copy(crop = CropRect(left, top, right, bottom))) }) { Text("Apply") } }, dismissButton = { TextButton(onClick = { onResult(null) }) { Text("Cancel") } })
}

@Composable private fun ExportScreen(pages: List<PageItem>, settings: PdfSettings, onSettings: (PdfSettings) -> Unit, processing: Boolean, progress: Pair<Int, Int>, onCancel: () -> Unit, onBack: () -> Unit, onExport: () -> Unit, error: String?, clearError: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        TopBar("Export", onBack)
        LazyColumn(Modifier.weight(1f).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item { Text("${pages.size} pages", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold) }
            item { SectionTitle("Page") }
            item { EnumSelector("Page size", settings.pageSize.label, PageSize.values().map { it.label }) { label -> PageSize.values().firstOrNull { it.label == label }?.let { onSettings(settings.copy(pageSize = it)) } } }
            if (settings.pageSize == PageSize.CUSTOM) {
                item { SliderRow("Custom width (mm)", settings.customWidthMm, 50f..500f) { onSettings(settings.copy(customWidthMm = it)) } }
                item { SliderRow("Custom height (mm)", settings.customHeightMm, 50f..700f) { onSettings(settings.copy(customHeightMm = it)) } }
            }
            item { EnumSelector("Orientation", settings.orientation.label, Orientation.values().map { it.label }) { label -> onSettings(settings.copy(orientation = Orientation.values().first { it.label == label })) } }
            item { EnumSelector("Placement", settings.fitMode.label, FitMode.values().map { it.label }) { label -> onSettings(settings.copy(fitMode = FitMode.values().first { it.label == label })) } }
            item { SliderRow("Margin (mm)", settings.marginMm, 0f..25f) { onSettings(settings.copy(marginMm = it)) } }
            item { SectionTitle("Quality") }
            item { EnumSelector("Quality", settings.quality.label, Quality.values().map { it.label }) { label -> onSettings(settings.copy(quality = Quality.values().first { it.label == label })) } }
            item { EnumSelector("Compression", settings.compression.label, Compression.values().map { it.label }) { label -> onSettings(settings.copy(compression = Compression.values().first { it.label == label })) } }
            item { Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(settings.addPageNumbers, { onSettings(settings.copy(addPageNumbers = it)) }); Text("Page numbers") } }
            item { OutlinedTextField(value = settings.watermark, onValueChange = { onSettings(settings.copy(watermark = it)) }, label = { Text("Watermark (optional)") }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(value = settings.title, onValueChange = { onSettings(settings.copy(title = it)) }, label = { Text("PDF title / filename") }, modifier = Modifier.fillMaxWidth()) }
            item { Text("Privacy: files are processed locally on this device. Nothing is uploaded by the core workflow.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
        if (processing) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                LinearProgressIndicator(progress = { if (progress.second == 0) 0f else progress.first.toFloat() / progress.second }, Modifier.fillMaxWidth())
                Text("Processing page ${progress.first} of ${progress.second}…")
                OutlinedButton(onClick = onCancel, Modifier.fillMaxWidth()) { Text("Cancel") }
            }
        } else {
            Button(onClick = onExport, enabled = pages.isNotEmpty(), Modifier.fillMaxWidth().padding(16.dp).height(54.dp)) { Text("Create PDF") }
        }
    }
    if (error != null) AlertDialog(onDismissRequest = clearError, confirmButton = { TextButton(onClick = clearError) { Text("OK") } }, title = { Text("Export failed") }, text = { Text(error) })
}

@Composable private fun PdfHistoryScreen(records: List<PdfRecord>, onOpen: (PdfRecord) -> Unit, onShare: (PdfRecord) -> Unit, onDelete: (PdfRecord) -> Unit, onRename: (PdfRecord, String) -> Unit) {
    var query by remember { mutableStateOf("") }
    var deleteCandidate by remember { mutableStateOf<PdfRecord?>(null) }
    var renameCandidate by remember { mutableStateOf<PdfRecord?>(null) }
    val filtered = records.filter { it.name.contains(query, true) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("My PDFs", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(value = query, onValueChange = { query = it }, singleLine = true, label = { Text("Search PDFs") }, leadingIcon = { Icon(Icons.Default.Search, null) }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        if (filtered.isEmpty()) EmptyState("No saved PDFs", "Created PDFs will appear here.", Modifier.fillMaxSize().weight(1f)) else LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) { items(filtered) { rec -> PdfRow(rec, onOpen, onShare, { renameCandidate = rec }, { deleteCandidate = rec }) } }
    }
    deleteCandidate?.let { rec -> AlertDialog(onDismissRequest = { deleteCandidate = null }, title = { Text("Delete PDF?") }, text = { Text("${rec.name} will be permanently deleted from app storage.") }, confirmButton = { TextButton(onClick = { onDelete(rec); deleteCandidate = null }) { Text("Delete") } }, dismissButton = { TextButton(onClick = { deleteCandidate = null }) { Text("Cancel") } }) }
    renameCandidate?.let { rec -> var name by remember(rec.id) { mutableStateOf(rec.name) }; AlertDialog(onDismissRequest = { renameCandidate = null }, title = { Text("Rename PDF") }, text = { OutlinedTextField(name, { name = it }, singleLine = true) }, confirmButton = { TextButton(onClick = { onRename(rec, name.ifBlank { rec.name }); renameCandidate = null }) { Text("Save") } }, dismissButton = { TextButton(onClick = { renameCandidate = null }) { Text("Cancel") } }) }
}

@Composable private fun SettingsScreen(dark: Boolean, onDarkChange: (Boolean) -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Settings", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        SettingRow("Dark mode", "Use a darker interface", dark, onDarkChange)
        Text("Default page size", fontWeight = FontWeight.SemiBold); Text("A4")
        Text("Default quality", fontWeight = FontWeight.SemiBold); Text("High")
        Text("Default compression", fontWeight = FontWeight.SemiBold); Text("Balanced")
        Divider()
        Text("Privacy", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
        Text("The main workflow uses Android storage access and local processing. Original images are never overwritten by the PDF export path.", color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable private fun AboutScreen() { Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) { Text("PDF Maker", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold); Text("Offline-first Image-to-PDF utility for Android."); Text("Designed for reliable conversion on low-end devices: thumbnails for UI, one-page-at-a-time decoding, native PDF generation, and clear failure messages."); Text("Core export: fully local. Advanced OCR/document-edge detection can be added as optional ML modules without making the core uploader/cloud dependent.", color = MaterialTheme.colorScheme.onSurfaceVariant) } }

@Composable private fun OnboardingDialog(onDone: () -> Unit) { AlertDialog(onDismissRequest = onDone, title = { Text("Welcome to PDF Maker") }, text = { Text("Select images, arrange pages, make edits, then create and share a PDF. Core processing stays on your device.") }, confirmButton = { TextButton(onClick = onDone) { Text("Got it") } }) }

@Composable private fun ActionCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit, modifier: Modifier = Modifier) { ElevatedCard(onClick = onClick, modifier = modifier.height(132.dp)) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { Icon(icon, null, tint = MaterialTheme.colorScheme.primary); Text(title, fontWeight = FontWeight.Bold); Text(subtitle, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) } } }
@Composable private fun EmptyState(title: String, body: String, modifier: Modifier = Modifier) { Column(modifier.fillMaxWidth().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) { Icon(Icons.Default.InsertDriveFile, null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.primary); Spacer(Modifier.height(8.dp)); Text(title, fontWeight = FontWeight.SemiBold); Text(body, color = MaterialTheme.colorScheme.onSurfaceVariant) } }
@Composable private fun TopBar(title: String, onBack: () -> Unit) { Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") }; Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold) } }
@Composable private fun SectionTitle(text: String) { Text(text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold) }
@Composable private fun SliderRow(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) { Column { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(label); Text(String.format(Locale.US, "%.2f", value), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }; Slider(value, onChange, valueRange = range) } }
@Composable private fun EnumSelector(label: String, current: String, options: List<String>, onSelect: (String) -> Unit) { var expanded by remember(label, current) { mutableStateOf(false) }; Box { OutlinedButton(onClick = { expanded = true }, Modifier.fillMaxWidth()) { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(label); Text(current, fontWeight = FontWeight.SemiBold) } }; DropdownMenu(expanded, { expanded = false }) { options.forEach { o -> DropdownMenuItem(text = { Text(o) }, onClick = { expanded = false; onSelect(o) }) } } } }
@Composable private fun SettingRow(label: String, description: String, checked: Boolean, onChange: (Boolean) -> Unit) { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(label, fontWeight = FontWeight.SemiBold); Text(description, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }; Switch(checked, onChange) } }

@Composable private fun Thumbnail(uri: Uri, modifier: Modifier, maxSide: Int = 420) {
    val context = LocalContext.current
    var bitmap by remember(uri) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(uri) { bitmap = with(kotlinx.coroutines.Dispatchers.IO) { ImageProcessor.loadThumbnail(context, uri, maxSide) } }
    if (bitmap == null) Box(modifier.background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) { CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp) }
    else Image(bitmap!!.asImageBitmap(), null, modifier, contentScale = ContentScale.Crop)
}

@Composable private fun PdfRow(rec: PdfRecord, onOpen: (PdfRecord) -> Unit, onShare: ((PdfRecord) -> Unit)? = null, onRename: (() -> Unit)? = null, onDelete: (() -> Unit)? = null) {
    Card(Modifier.fillMaxWidth()) { Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.PictureAsPdf, null, Modifier.size(42.dp), tint = MaterialTheme.colorScheme.primary); Column(Modifier.weight(1f).padding(horizontal = 12.dp)) { Text(rec.name, fontWeight = FontWeight.SemiBold); Text("${rec.pageCount} pages • ${formatBytes(rec.bytes)} • ${formatDate(rec.createdAt)}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }; IconButton(onClick = { onOpen(rec) }) { Icon(Icons.Default.OpenInNew, "Open") }; if (onShare != null) IconButton(onClick = { onShare(rec) }) { Icon(Icons.Default.Share, "Share") }; if (onRename != null) IconButton(onClick = onRename) { Icon(Icons.Default.Edit, "Rename") }; if (onDelete != null) IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, "Delete") } } }
}
private fun formatBytes(n: Long): String = when { n < 1024 -> "$n B"; n < 1024*1024 -> "%.1f KB".format(n/1024.0); else -> "%.1f MB".format(n/1024.0/1024.0) }
private fun formatDate(ms: Long) = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(Date(ms))
