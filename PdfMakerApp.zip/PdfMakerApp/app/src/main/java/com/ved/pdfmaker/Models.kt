package com.ved.pdfmaker

import android.net.Uri

// Kept immutable so Compose can safely render and re-order page state.
data class PageItem(
    val id: Long,
    val uri: Uri,
    val rotation: Int = 0,
    val crop: CropRect? = null,
    val brightness: Float = 0f,
    val contrast: Float = 1f,
    val saturation: Float = 1f,
    val grayscale: Boolean = false,
    val blackAndWhite: Boolean = false
)

data class CropRect(val left: Float, val top: Float, val right: Float, val bottom: Float)

data class PdfSettings(
    val pageSize: PageSize = PageSize.A4,
    val orientation: Orientation = Orientation.PORTRAIT,
    val marginMm: Float = 8f,
    val fitMode: FitMode = FitMode.FIT,
    val quality: Quality = Quality.HIGH,
    val compression: Compression = Compression.BALANCED,
    val title: String = "",
    val author: String = "",
    val subject: String = "",
    val keywords: String = "",
    val addPageNumbers: Boolean = false,
    val watermark: String = "",
    val customWidthMm: Float = 210f,
    val customHeightMm: Float = 297f
)

enum class PageSize(val label: String, val widthMm: Float, val heightMm: Float) {
    A4("A4", 210f, 297f),
    A5("A5", 148f, 210f),
    LETTER("Letter", 215.9f, 279.4f),
    LEGAL("Legal", 215.9f, 355.6f),
    SQUARE("Square", 210f, 210f),
    CUSTOM("Custom", 210f, 297f)
}

enum class Orientation(val label: String) { PORTRAIT("Portrait"), LANDSCAPE("Landscape") }
enum class FitMode(val label: String) { FIT("Fit"), FILL("Fill"), CENTER("Center") }
enum class Quality(val label: String, val jpeg: Int, val maxSidePx: Int) {
    LOW("Low", 55, 1600), MEDIUM("Medium", 72, 2200), HIGH("High", 88, 3000), ORIGINAL("Original", 95, 4200)
}
enum class Compression(val label: String) { MAX("Maximum"), BALANCED("Balanced"), HIGH("High quality"), NONE("Low/no") }

data class PdfRecord(
    val id: Long,
    val name: String,
    val path: String,
    val createdAt: Long,
    val bytes: Long,
    val pageCount: Int
)

enum class Screen { HOME, CREATE, ORGANIZE, EDIT, EXPORT, PDFS, SETTINGS, ABOUT }
