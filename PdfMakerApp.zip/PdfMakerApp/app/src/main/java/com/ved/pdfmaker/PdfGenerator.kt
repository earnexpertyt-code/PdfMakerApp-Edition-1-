package com.ved.pdfmaker

import android.content.Context
import android.graphics.*
import java.io.File
import java.io.FileOutputStream
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import kotlin.math.roundToInt

object PdfGenerator {
    data class Result(val file: File, val pages: Int, val warnings: List<String> = emptyList())

    fun generate(
        context: Context,
        pages: List<PageItem>,
        settings: PdfSettings,
        outputDir: File,
        onProgress: (Int, Int) -> Unit,
        isCancelled: () -> Boolean
    ): Result {
        require(pages.isNotEmpty()) { "No pages selected" }
        outputDir.mkdirs()
        val safeName = sanitize(settings.title.ifBlank { "PDF_${System.currentTimeMillis()}" }) + ".pdf"
        val outFile = File(outputDir, uniqueName(outputDir, safeName))
        val doc = android.graphics.pdf.PdfDocument()
        val warnings = mutableListOf<String>()
        val dims = pageDimensions(settings)
        try {
            pages.forEachIndexed { index, item ->
                if (isCancelled()) throw CancellationException()
                onProgress(index + 1, pages.size)
                val effectiveQuality = effectiveQuality(settings)
                val bitmap = ImageProcessor.loadForPdf(context, item, settings.quality)
                    ?: run { warnings += "Skipped unreadable page ${index + 1}"; return@forEachIndexed }
                val pageInfo = android.graphics.pdf.PdfDocument.PageInfo.Builder(dims.first, dims.second, index + 1).create()
                val page = doc.startPage(pageInfo)
                val canvas = page.canvas
                canvas.drawColor(Color.WHITE)
                val marginPx = mmToPx(settings.marginMm, 72f)
                val target = RectF(marginPx, marginPx, dims.first - marginPx, dims.second - marginPx)
                drawBitmap(canvas, bitmap, target, settings.fitMode)
                if (settings.watermark.isNotBlank()) drawWatermark(canvas, settings.watermark, dims.first, dims.second)
                if (settings.addPageNumbers) {
                    val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.DKGRAY; textSize = 10f }
                    canvas.drawText("${index + 1} / ${pages.size}", dims.first - 55f, dims.second - 20f, p)
                }
                doc.finishPage(page)
                bitmap.recycle()
            }
            FileOutputStream(outFile).use { doc.writeTo(it) }
            if (settings.title.isNotBlank() || settings.author.isNotBlank() || settings.subject.isNotBlank() || settings.keywords.isNotBlank()) {
                try {
                    PDFBoxResourceLoader.init(context)
                    val temp = File.createTempFile("metadata_", ".pdf", outFile.parentFile)
                    PDDocument.load(outFile).use { pdf ->
                        if (settings.title.isNotBlank()) pdf.documentInformation.title = settings.title
                        if (settings.author.isNotBlank()) pdf.documentInformation.author = settings.author
                        if (settings.subject.isNotBlank()) pdf.documentInformation.subject = settings.subject
                        if (settings.keywords.isNotBlank()) pdf.documentInformation.keywords = settings.keywords
                        pdf.save(temp)
                    }
                    if (!outFile.delete() || !temp.renameTo(outFile)) warnings += "PDF created, but metadata could not be embedded."
                } catch (e: Exception) { warnings += "PDF created, but metadata could not be embedded." }
            }
        } finally {
            doc.close()
        }
        return Result(outFile, pages.size, warnings)
    }

    private fun effectiveQuality(s: PdfSettings): Int = when (s.compression) {
        Compression.MAX -> (s.quality.jpeg - 22).coerceAtLeast(35)
        Compression.BALANCED -> (s.quality.jpeg - 8).coerceAtLeast(45)
        Compression.HIGH -> (s.quality.jpeg + 2).coerceAtMost(96)
        Compression.NONE -> s.quality.jpeg
    }

    private fun drawBitmap(canvas: Canvas, bitmap: Bitmap, target: RectF, mode: FitMode) {
        val bw = bitmap.width.toFloat(); val bh = bitmap.height.toFloat()
        val sx = target.width() / bw; val sy = target.height() / bh
        val scale = when (mode) { FitMode.FIT, FitMode.CENTER -> minOf(sx, sy); FitMode.FILL -> maxOf(sx, sy) }
        val dw = bw * scale; val dh = bh * scale
        val left = target.centerX() - dw / 2f; val top = target.centerY() - dh / 2f
        val src = Rect(0, 0, bitmap.width, bitmap.height)
        val dst = RectF(left, top, left + dw, top + dh)
        canvas.drawBitmap(bitmap, src, dst, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
    }

    private fun drawWatermark(canvas: Canvas, text: String, width: Int, height: Int) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(55, 70, 70, 70); textSize = 28f; textAlign = Paint.Align.CENTER }
        canvas.save(); canvas.rotate(-35f, width / 2f, height / 2f); canvas.drawText(text, width / 2f, height / 2f, paint); canvas.restore()
    }

    private fun pageDimensions(s: PdfSettings): Pair<Int, Int> {
        var w = (s.pageSize.widthMm / 25.4f * 72f).roundToInt()
        var h = (s.pageSize.heightMm / 25.4f * 72f).roundToInt()
        if (s.pageSize == PageSize.CUSTOM) { w = (s.customWidthMm / 25.4f * 72f).roundToInt(); h = (s.customHeightMm / 25.4f * 72f).roundToInt() }
        return if (s.orientation == Orientation.LANDSCAPE) h to w else w to h
    }

    private fun mmToPx(mm: Float, dpi: Float) = mm / 25.4f * dpi
    private fun sanitize(s: String) = s.replace(Regex("[^A-Za-z0-9 _-]"), "_").trim().ifBlank { "document" }
    private fun uniqueName(dir: File, name: String): String {
        if (!File(dir, name).exists()) return name
        var i = 2
        while (File(dir, name.removeSuffix(".pdf") + " ($i).pdf").exists()) i++
        return name.removeSuffix(".pdf") + " ($i).pdf"
    }
    class CancellationException : RuntimeException()
}
