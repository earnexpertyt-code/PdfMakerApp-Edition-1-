package com.ved.pdfmaker

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class DocumentStore(context: Context) {
    private val prefs = context.getSharedPreferences("pdf_store", Context.MODE_PRIVATE)
    private val key = "records"

    fun list(): List<PdfRecord> {
        val json = JSONArray(prefs.getString(key, "[]") ?: "[]")
        return buildList {
            for (i in 0 until json.length()) {
                val o = json.optJSONObject(i) ?: continue
                add(PdfRecord(o.optLong("id"), o.optString("name"), o.optString("path"), o.optLong("createdAt"), o.optLong("bytes"), o.optInt("pageCount")))
            }
        }.filter { File(it.path).exists() }
            .sortedByDescending { it.createdAt }
    }

    fun add(record: PdfRecord) {
        val arr = JSONArray()
        list().filterNot { it.id == record.id }.take(100).forEach { arr.put(toJson(it)) }
        arr.put(toJson(record))
        prefs.edit().putString(key, arr.toString()).apply()
    }

    fun remove(id: Long) {
        val arr = JSONArray()
        list().filterNot { it.id == id }.forEach { arr.put(toJson(it)) }
        prefs.edit().putString(key, arr.toString()).apply()
    }

    fun rename(id: Long, name: String) {
        val old = list().firstOrNull { it.id == id } ?: return
        val updated = old.copy(name = name)
        val arr = JSONArray(); list().map { if (it.id == id) updated else it }.forEach { arr.put(toJson(it)) }
        prefs.edit().putString(key, arr.toString()).apply()
    }

    private fun toJson(r: PdfRecord) = JSONObject().apply {
        put("id", r.id); put("name", r.name); put("path", r.path); put("createdAt", r.createdAt); put("bytes", r.bytes); put("pageCount", r.pageCount)
    }
}
