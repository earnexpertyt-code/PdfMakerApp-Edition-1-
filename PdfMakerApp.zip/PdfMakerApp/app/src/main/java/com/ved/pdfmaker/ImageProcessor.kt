package com.ved.pdfmaker

import android.content.Context
import android.graphics.*
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max

object ImageProcessor {
    fun loadThumbnail(context: Context, uri: Uri, maxSide: Int = 420): Bitmap? {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            val sample = calculateInSampleSize(bounds.outWidth, bounds.outHeight, maxSide)
            val opts = BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = Bitmap.Config.RGB_565 }
            context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        } catch (_: Exception) { null }
    }

    fun loadForPdf(context: Context, page: PageItem, quality: Quality): Bitmap? {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            context.contentResolver.openInputStream(page.uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
            val sample = calculateInSampleSize(bounds.outWidth, bounds.outHeight, quality.maxSidePx)
            val opts = BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = Bitmap.Config.ARGB_8888 }
            val raw = context.contentResolver.openInputStream(page.uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
            process(raw, page)
        } catch (_: Exception) { null }
    }

    fun process(source: Bitmap, page: PageItem): Bitmap {
        var bitmap = source
        if (page.crop != null) {
            val c = page.crop
            val l = (c.left * bitmap.width).toInt().coerceIn(0, bitmap.width - 1)
            val t = (c.top * bitmap.height).toInt().coerceIn(0, bitmap.height - 1)
            val r = (c.right * bitmap.width).toInt().coerceIn(l + 1, bitmap.width)
            val b = (c.bottom * bitmap.height).toInt().coerceIn(t + 1, bitmap.height)
            bitmap = Bitmap.createBitmap(bitmap, l, t, r - l, b - t)
        }
        if (page.rotation % 360 != 0) {
            val m = Matrix().apply { postRotate(page.rotation.toFloat()) }
            bitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, m, true)
        }
        if (page.brightness != 0f || page.contrast != 1f || page.saturation != 1f || page.grayscale || page.blackAndWhite) {
            val out = Bitmap.createBitmap(bitmap.width, bitmap.height, Bitmap.Config.ARGB_8888)
            val cm = ColorMatrix()
            val values = floatArrayOf(
                page.contrast, 0f, 0f, 0f, page.brightness * 255f,
                0f, page.contrast, 0f, 0f, page.brightness * 255f,
                0f, 0f, page.contrast, 0f, page.brightness * 255f,
                0f, 0f, 0f, 1f, 0f
            )
            cm.set(values)
            val sat = if (page.grayscale || page.blackAndWhite) 0f else page.saturation
            val satMatrix = ColorMatrix().apply { setSaturation(sat) }
            cm.postConcat(satMatrix)
            if (page.blackAndWhite) {
                cm.postConcat(ColorMatrix(floatArrayOf(
                    3f, 3f, 3f, 0f, -430f,
                    3f, 3f, 3f, 0f, -430f,
                    3f, 3f, 3f, 0f, -430f,
                    0f, 0f, 0f, 1f, 0f
                )))
            }
            Canvas(out).drawBitmap(bitmap, 0f, 0f, Paint(Paint.ANTI_ALIAS_FLAG).apply { colorFilter = ColorMatrixColorFilter(cm) })
            if (bitmap !== source) bitmap.recycle()
            bitmap = out
        }
        return bitmap
    }

    fun writeTempJpeg(context: Context, bitmap: Bitmap, quality: Int): File {
        val dir = File(context.cacheDir, "processed").apply { mkdirs() }
        val file = File.createTempFile("page_", ".jpg", dir)
        FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.JPEG, quality, it) }
        return file
    }

    fun calculateInSampleSize(w: Int, h: Int, maxSide: Int): Int {
        var sample = 1
        while (max(w / sample, h / sample) > maxSide) sample *= 2
        return sample.coerceAtLeast(1)
    }
}
